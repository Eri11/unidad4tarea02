/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea4.pkg2;

/**
 *
 * @author Erick Hernández
 */
public class Tarea42 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //Se declara un objeto de la clase Contacto, para ayudarnos a iniciar con el programa
          Producto aux= new Producto();
          //Se manda llamar el menu de la clase Contacto.
          //En donde se realizaran todas las operaciones
          //del programa         
          aux.menu();
    }
    
}
